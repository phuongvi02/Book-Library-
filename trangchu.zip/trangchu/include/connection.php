<?php 
$servername ="localhost:3306";
$username = "root";
$password = "";
$dbname = "thuvien_btl";

//khoi tao ket noi
$conn = new mysqli($servername, $username, $password, $dbname);

//kiem tra ket noi
if($conn->connect_error){
    die("ket noi that bai" . $conn->connect_error);
}
?>