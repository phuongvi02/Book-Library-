<?php 

$servername ="localhost:3306";
    $username = "root";
    $password = "";
    $dbname = "thuvien_btl";
    
    //khoi tao ket noi
    $conn = new mysqli($servername, $username, $password, $dbname);
 
    $idtac_gia = $_POST['idtg'];
    $name_tg = $_POST['nametg'];

    // $sql1= "INSERT INTO sach(masach, tensach, idtacgia, theloai, soluong, tinhtrang, NXB, namxuatban) values($masach, '$tensach', $idtacgia, $idtheloai, $soluong, $idtinhtrang, $idnxb, $nam_xb) ";
    // $result1 = $conn->query($sql1);
    $stmt = $conn->prepare("INSERT INTO tacgia(idtacga, tentacgia) values(?, ?)");
    $stmt->bind_param("ss", $idtac_gia, $name_tg);
     if($stmt->execute()){
        echo "thêm thông tin thành công";
    }else {
        echo "thêm thông tin thất bại";
    }

    header("Location: index.php");
?>