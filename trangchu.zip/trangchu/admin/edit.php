<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin sách </title>
</head>
<body>
     <?php 
     $servername ="localhost:3306";
     $username = "root";
     $password = "";
     $dbname = "thuvien_btl";
 
     //khoi tao ket noi
     $conn = new mysqli($servername, $username, $password, $dbname);
 
     //kiem tra ket noi
     if($conn->connect_error){
         die("ket noi that bai" . $conn->connect_error);
     }


    $masach= $_POST['masach'];
    $tensach = $_POST['tensach'];
    $idtacgia= $_POST['matacgia'];
    $theloai= $_POST['matheloai'];
    $soluong= $_POST['soluong'];
    $tinhtrang = $_POST['matinhtrang'];
    $NXB= $_POST['idnxb'];
    $namxuatban= $_POST['namxb'];
     $stmt = $conn->prepare("UPDATE sach SET tensach=?, idtacgia=?, theloai=?, soluong=?, tinhtrang=?, NXB=?, namxuatban=? WHERE masach =?");
     $stmt->bind_param("ssssssss", $tensach, $idtacgia, $theloai, $soluong, $tinhtrang, $NXB, $namxuatban, $masach);
     if($stmt->execute()){
        echo "sửa thông tin thành công";
    }else {
        echo "sửa thông tin thất bại";
    }
    



    header("Location: muonsach.php");
     ?><br>
    
</body>
</html>