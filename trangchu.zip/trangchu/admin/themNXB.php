<?php 

$servername ="localhost:3306";
    $username = "root";
    $password = "";
    $dbname = "thuvien_btl";
    
    //khoi tao ket noi
    $conn = new mysqli($servername, $username, $password, $dbname);
 
    $id_nxb = $_POST['idNXB'];
    $name_nxb = $_POST['nameNXB'];

    // $sql1= "INSERT INTO sach(masach, tensach, idtacgia, theloai, soluong, tinhtrang, NXB, namxuatban) values($masach, '$tensach', $idtacgia, $idtheloai, $soluong, $idtinhtrang, $idnxb, $nam_xb) ";
    // $result1 = $conn->query($sql1);
    $stmt = $conn->prepare("INSERT INTO nhaxuatban(idxuatban, tennhaxuatban) values(?, ?)");
    $stmt->bind_param("ss", $id_nxb, $name_nxb);
     if($stmt->execute()){
        echo "Thêm thông tin thành công";
    }else {
        echo "Thêm thông tin thất bại";
    }
    header("Location: index.php");
?>